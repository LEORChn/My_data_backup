---
title: 警察胸章
---



## 历史



## 99式

|      |               |                         |
| ---- | ------------- | ----------------------- |
|      | [省份] POLICE |                         |
|      | 安全 POLICE   | ？国家安全警察/经济警察 |
|      | 司法 POLICE   | 司法警察                |
|      | 法院 POLICE   |                         |
|      | 检察 POLICE   |                         |
|      | 公直 POLICE   | 公安部直属单位          |
|      | 公安部 POLICE |                         |

https://zhuanlan.zhihu.com/p/252760755

## 资料库

* https://zhuanlan.zhihu.com/p/252760755